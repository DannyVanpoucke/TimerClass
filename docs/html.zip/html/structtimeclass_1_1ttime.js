var structtimeclass_1_1ttime =
[
    [ "add", "structtimeclass_1_1ttime.html#ac2f12d68ac6782ae35c8bdec8d98bf8c", null ],
    [ "assignment", "structtimeclass_1_1ttime.html#ad9d449f3a7640dd75efbb954a60287a8", null ],
    [ "calculatejdn", "structtimeclass_1_1ttime.html#a90da7d601f202836957ae06fe79a30bd", null ],
    [ "constructor", "structtimeclass_1_1ttime.html#a0a06dd06566d810bbd7aca7c97dbc3fe", null ],
    [ "copy", "structtimeclass_1_1ttime.html#a06fcabfcd288ebe602e1dd48712c7943", null ],
    [ "destructor", "structtimeclass_1_1ttime.html#a91fef160b4d8636cc9f909a243e89217", null ],
    [ "getjuliandaynumber", "structtimeclass_1_1ttime.html#ada6df4315edac32f402eb155c3a8db57", null ],
    [ "gettimeseconds", "structtimeclass_1_1ttime.html#a971c6081c5962be1272f15f9b8ddad0c", null ],
    [ "gettimestring", "structtimeclass_1_1ttime.html#a4e9e0dc4685d90f9bdcef5c7ed71e36f", null ],
    [ "isleapyear", "structtimeclass_1_1ttime.html#aba704ee420280dc58e90b61de63cadba", null ],
    [ "operator", "structtimeclass_1_1ttime.html#a765301729b3cb92b0e894657c7e6acd8", null ],
    [ "operator", "structtimeclass_1_1ttime.html#a7512716925c6c546b81fe0d98ae488cc", null ],
    [ "setgregoriandatefromjdn", "structtimeclass_1_1ttime.html#a3a0296fab0d694b1b067546882fd9d50", null ],
    [ "setjdn", "structtimeclass_1_1ttime.html#ab8f7f4828206f88ebb5bf3a2b8bfa66a", null ],
    [ "settime", "structtimeclass_1_1ttime.html#a5b560461952a3788a002668d841f749a", null ],
    [ "subtract", "structtimeclass_1_1ttime.html#a5e36166658521dfb0660d0b6b6b14c5c", null ],
    [ "day", "structtimeclass_1_1ttime.html#a1906c6ab016ce308a61cd285640bdb37", null ],
    [ "daysecs", "structtimeclass_1_1ttime.html#a2f2766fa5027412be8c19e1baa2b1d25", null ],
    [ "jdn", "structtimeclass_1_1ttime.html#a437dbb28407dda2ea339112d0b0c7b8b", null ],
    [ "month", "structtimeclass_1_1ttime.html#a77df993547c9a4da49c3cf875176def6", null ],
    [ "year", "structtimeclass_1_1ttime.html#a0b9838220f0ac975a9a76a07d9d7964e", null ]
];
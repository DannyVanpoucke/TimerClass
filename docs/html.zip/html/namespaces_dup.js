var namespaces_dup =
[
    [ "timeclass", "namespacetimeclass.html", null ],
    [ "timerclass", "namespacetimerclass.html", null ]
];
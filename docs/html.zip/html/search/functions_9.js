var searchData=
[
  ['placed_58',['placed',['../structtimeclass_1_1ttime.html#a4d62612d7f2904afc592716d66c2de9d',1,'timeclass::ttime']]]
];

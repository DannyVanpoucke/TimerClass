var searchData=
[
  ['setgregoriandatefromjdn_59',['setgregoriandatefromjdn',['../structtimeclass_1_1ttime.html#a3a0296fab0d694b1b067546882fd9d50',1,'timeclass::ttime::setgregoriandatefromjdn()'],['../namespacetimeclass.html#a5812a48301de935d827873ae98027371',1,'timeclass::setgregoriandatefromjdn()']]],
  ['setjdn_60',['setjdn',['../structtimeclass_1_1ttime.html#ab8f7f4828206f88ebb5bf3a2b8bfa66a',1,'timeclass::ttime::setjdn()'],['../namespacetimeclass.html#ae2e5e8e965cd98525478baa4f1c7bf67',1,'timeclass::setjdn()']]],
  ['settime_61',['settime',['../structtimeclass_1_1ttime.html#a5b560461952a3788a002668d841f749a',1,'timeclass::ttime::settime()'],['../namespacetimeclass.html#acf1ef0491f0ac95a590d42cd53fc924c',1,'timeclass::settime()']]],
  ['subtract_62',['subtract',['../structtimeclass_1_1ttime.html#a5e36166658521dfb0660d0b6b6b14c5c',1,'timeclass::ttime::subtract()'],['../namespacetimeclass.html#aaa04d0a6a95d97944ece4cc3347e042b',1,'timeclass::subtract()']]]
];

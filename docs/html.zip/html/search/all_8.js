var searchData=
[
  ['operator_23',['operator',['../structtimeclass_1_1ttime.html#a765301729b3cb92b0e894657c7e6acd8',1,'timeclass::ttime::operator=&gt; add'],['../structtimeclass_1_1ttime.html#a7512716925c6c546b81fe0d98ae488cc',1,'timeclass::ttime::operator=&gt; subtract']]]
];

var searchData=
[
  ['day_78',['day',['../structtimeclass_1_1ttime.html#a1906c6ab016ce308a61cd285640bdb37',1,'timeclass::ttime']]],
  ['daysecs_79',['daysecs',['../structtimeclass_1_1ttime.html#a2f2766fa5027412be8c19e1baa2b1d25',1,'timeclass::ttime']]]
];

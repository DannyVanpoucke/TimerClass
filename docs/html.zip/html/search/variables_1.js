var searchData=
[
  ['jdn_80',['jdn',['../structtimeclass_1_1ttime.html#a437dbb28407dda2ea339112d0b0c7b8b',1,'timeclass::ttime']]]
];

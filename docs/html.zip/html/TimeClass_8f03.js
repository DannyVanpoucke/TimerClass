var TimeClass_8f03 =
[
    [ "ttime", "structtimeclass_1_1ttime.html", "structtimeclass_1_1ttime" ],
    [ "ttime", "structtimeclass_1_1ttime.html", "structtimeclass_1_1ttime" ],
    [ "add", "TimeClass_8f03.html#af784e5c0fa38632f4697dfab173b6fbc", null ],
    [ "calculatejdn", "TimeClass_8f03.html#aa9aa6cbf0a093ed2713f889185b33957", null ],
    [ "constructor", "TimeClass_8f03.html#a3c1704cd17f3303c83ec70603608c58f", null ],
    [ "copy", "TimeClass_8f03.html#af077b27e68775412e3747724a600fed9", null ],
    [ "destructor", "TimeClass_8f03.html#a724c57ab99d905a549e4e2da24770389", null ],
    [ "getjuliandaynumber", "TimeClass_8f03.html#a33a5024973ae5ae86727895fed2663be", null ],
    [ "gettimeseconds", "TimeClass_8f03.html#a4fcd307795ab2ab0e5682219d084d9c9", null ],
    [ "gettimestring", "TimeClass_8f03.html#a1b81827021db6eaeac2db5d87aeb24e4", null ],
    [ "isleapyear", "TimeClass_8f03.html#a1cc9f9ee8f24619e189aa7d60f17edb3", null ],
    [ "setgregoriandatefromjdn", "TimeClass_8f03.html#a5812a48301de935d827873ae98027371", null ],
    [ "setjdn", "TimeClass_8f03.html#ae2e5e8e965cd98525478baa4f1c7bf67", null ],
    [ "settime", "TimeClass_8f03.html#acf1ef0491f0ac95a590d42cd53fc924c", null ],
    [ "subtract", "TimeClass_8f03.html#aaa04d0a6a95d97944ece4cc3347e042b", null ]
];